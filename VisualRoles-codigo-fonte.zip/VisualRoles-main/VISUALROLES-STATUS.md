# VisualRoles — estado desta entrega

## Implementado nesta revisão
- Configuração mobile para ativar/desativar o plugin.
- Cadastro manual de atribuições locais por servidor, membro e ID de cargo existente.
- Nome e cor HEX da etiqueta visual.
- Lista das atribuições salvas e ação para removê-las.
- Persistência via `jsonStorage` do Revenge.
- Não há chamadas a endpoints de gerenciamento de cargos nem alterações de permissões.

## Ainda não implementado
A renderização das etiquetas na lista lateral de membros e no perfil ainda não está ligada. O APK fornecido contém um bundle Hermes compilado, mas não fornece os módulos-fonte/nomes estáveis dos componentes React necessários para instalar patches com segurança. A inspeção de strings não é suficiente para determinar assinaturas, props e ordem de renderização. Não foi criado um hook especulativo.

## Validação
O ambiente desta entrega não tem Bun nem dependências instaladas; portanto não foi possível executar o bundler oficial nem validar o pacote no dispositivo. Este ZIP é código-fonte revisado, não um ZIP de plugin instalável nem uma publicação de repositório.
